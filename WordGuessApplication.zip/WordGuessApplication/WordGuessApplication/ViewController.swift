//
//  ViewController.swift
//  WordGuessApplication
//
//  Created by Vattumilli,Bala Venkata Sai Kishore on 2/27/24.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var displayLabelOL: UILabel!
    
    
    
    @IBOutlet weak var hintLabelOL: UILabel!
    
    
    @IBOutlet weak var textOL: UITextField!
    
    
    @IBOutlet weak var checkOL: UIButton!
    
    
    
    @IBOutlet weak var statusLabelOL: UILabel!
    
    
    @IBOutlet weak var playAgainOL: UIButton!
    
    //declare and initialising the array
    var words = [["SWIFT","Programming Language"],["Dog","Animal"],["CAR","Four Wheeler"],["IPHONE","Apple Device"]]
     var count = 0
    var letterGuessed = ""
    var word = ""
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        //update the underscore
        updateUnderScores();
        
        //enable the check button
        checkOL.isEnabled = false
        //hidden play again button
        
    
        //hint for the word
        hintLabelOL.text! = "Hint: "+words[count][1]
        
        
        //initially clearing the status label
        statusLabelOL.text = ""
        
        //getting the first word from the array
        
        word = words[count][0]
        displayLabelOL.text = ""
        
        
        
    }

    @IBAction func textChange(_ sender: Any) {
        
        //entering single character
        
        var letter = textOL.text!
        letterGuessed = letterGuessed + letter
        var reveledWord = ""
        
        for l in word{
            if letterGuessed.contains(l)
            {
                reveledWord += "\(l)"
            }
            else
            {
                reveledWord += "_"
            }
        }
        //assigning the reveled word
        
        displayLabelOL.text = reveledWord
        
        textOL.text = ""
        
        if displayLabelOL.text!.contains("_") == false{
            playAgainOL.isHidden = false
            checkOL.isEnabled = false
        }
        
        checkOL.isEnabled = false
        
    }
    
    @IBAction func checkButtonClicked(_ sender: Any) {
        
        
        //check button enabled
        
        //verify the enter character is present in the give array
        
        //enter the character in the array if it is present
    }
    
    
    @IBAction func playAgainButtonClicked(_ sender: Any) {
        
        
        //if the ward is gussed then un hide the paly again
        
        //move to next hint
        
        //if the array length is equal to count then display the status label
        
        //text field empty
        
        
        //check button disabled
        
    }
    
    

}

