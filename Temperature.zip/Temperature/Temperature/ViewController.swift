//
//  ViewController.swift
//  Temperature
//
//  Created by Vattumilli,Bala Venkata Sai Kishore on 1/25/24.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var inputOL: UITextField!
    
    @IBOutlet weak var outputOL: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func SubmitBtn(_ sender: Any) {
        
        var input = Int(inputOL.text!)
        
        if(input! >= 60)
        {
            outputOL.text = "It's too hot 🥵 "
        }
        else
        {
            outputOL.text = "It's too cold 🥶"
        }
        
        
        
        
    }
    
}
