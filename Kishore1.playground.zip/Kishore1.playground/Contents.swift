import UIKit

var greeting = "Hello, playground"

print("""
Hello
World!
""")/*printing the sentence in the new line use triple quotes*/
print("Hello All,\rWelcome to Swift Programming")

let welcomeMessage : String = "Hello"
print(welcomeMessage,"👍All")

var age = 23
print("You are \(age) 😮‍💨years old and in another \(age) years,you will be \(age * 2)")
print("Welcome to swift programming language")
print("Fall 2021")
print("***************")
print("Welcome to swift Programming", terminator : "-")
print("Fall 2021")


//In general, the items in a print statement are seperated by spaces , to print the items seperated by something other than spaces,we use seperator

print("The list of numbers are")
print(1,2,3,4,5,6)
print("the new pattern is")
print(1,2,3,4,5,6, separator: "-")

//Declaration of variable

var mobileBrand = "Apple"
mobileBrand = "Samsung"
print(mobileBrand)

let pi = 3.14 /*constant*/
print(pi)
//pi = 3.13
//Explicit Declaration of variable
var age1 : Int = 23
age1 = age1 * 2
print(age1)

var aweMessage = "This is Superb!"
print(aweMessage)
print("aweMessage")

var course1 = "ios"
print("This is",course1,"class")

