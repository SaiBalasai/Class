import UIKit

var greeting = "Hello, playground"

print("""
Hello
World!
""")/*printing the sentence in the new line use triple quotes*/
print("Hello All,\rWelcome to Swift Programming")

let welcomeMessage : String = "Hello"
print(welcomeMessage,"👍All")

var age = 23
print("You are \(age) 😮‍💨years old and in another \(age) years,you will be \(age * 2)")
print("Welcome to swift programming language")
print("Fall 2021")
print("***************")
print("Welcome to swift Programming", terminator : "-")
print("Fall 2021")


//In general, the items in a print statement are seperated by spaces , to print the items seperated by something other than spaces,we use seperator

print("The list of numbers are")
print(1,2,3,4,5,6)
print("the new pattern is")
print(1,2,3,4,5,6, separator: "-")
