//
//  ResultViewController.swift
//  Vattumilli_Exam02
//
//  Created by Bala Venkata Sai Kishore Vattumilli on 4/11/24.
//

import UIKit

class ResultViewController: UIViewController {
    
    var image = ""
    var patientID = ""
    var bloodPressure = ""
    var mBP = ""
    var result = ""
    var healthTip = ""
    
    
    
    @IBOutlet weak var imageViewOL: UIImageView!
    
    
    
    @IBOutlet weak var patientIDOL: UILabel!
    
    
    @IBOutlet weak var bloodPressureOL: UILabel!
    
    
    @IBOutlet weak var mBPOL: UILabel!
    
    
    @IBOutlet weak var resultOL: UILabel!
    
    
    
    @IBOutlet weak var healthTipOL: UILabel!
    
   
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        imageViewOL.image = UIImage(named: image)
        patientIDOL.text = patientID
        bloodPressureOL.text = bloodPressure
        resultOL.text = result
        mBPOL.text = String(mBP)
        healthTipOL.text = healthTip
        

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
