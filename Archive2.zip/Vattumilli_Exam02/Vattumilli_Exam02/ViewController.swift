//
//  ViewController.swift
//  Vattumilli_Exam02
//
//  Created by Bala Venkata Sai Kishore Vattumilli on 4/11/24.
//

import UIKit

class ViewController: UIViewController {
    
    var image = ""
    var patientID = ""
    var bloodPressure = ""
    var mBP = ""
    var result = ""
    var healthTip = ""
    
    
    @IBOutlet weak var patientIDOL: UITextField!
    
    
    @IBOutlet weak var systolicOL: UITextField!
    
    
    @IBOutlet weak var diastolicOL: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    
    
    @IBAction func CheckBloodPressure(_ sender: Any) {
        
        
        patientID = patientIDOL.text!
        var systolic = Int(systolicOL.text!)!
        var diastolic = Int(diastolicOL.text!)!
        var MBP = Double(0.667 * Double(diastolic)) + Double(0.334 * Double(systolic))
        if MBP <= 60
        {
            patientID = ("Patient ID: \(patientIDOL.text!)")
            result = ("Result: Stroke or Internal Bleeding")
            healthTip = ("Health Tip: Seek immediate medical Attention. 👨🏻‍⚕️")
            bloodPressure = ("Blood Pressure: \(systolic)/\(diastolic) mm Hg")
            mBP = ("MBP: \(MBP)")
            image = "stroke"
        }
        else if MBP > 60 && MBP <= 69
        {
            patientID = ("Patient ID: \(patientIDOL.text!)")
            result = ("Result: Hypotension")
            healthTip = ("HealthTip: Stay Hydrated 🥛")
            bloodPressure = ("Blood Pressure: \(systolic)/\(diastolic) mm Hg")
            mBP = ("MBP: \(MBP)")
            image = "hypotension"
        }
        else if MBP >= 70 && MBP <= 99
        {
            patientID = ("Patient ID: \(patientIDOL.text!)")
            result = ("Result: Healthy")
            healthTip = ("Health Tip: You are doing great 👍")
            bloodPressure = ("Blood Pressure: \(systolic)/\(diastolic) mm Hg")
            mBP = ("MBP: \(MBP)")
            image = "healthy"
        }
        else if MBP > 100 && MBP <= 106
        {
            patientID = ("Patient ID: \(patientIDOL.text!)")
            result = ("Result: Elevated")
            healthTip = ("Health Tip: Make sure to maintain workout 🏋️")
            
            bloodPressure = ("Blood Pressure: \(systolic)/\(diastolic) mm Hg")
            mBP = ("MBP: \(MBP)")
            image = "elevated"
        }
        else
        {
            patientID = ("Patient ID: \(patientIDOL.text!)")
            result = ("Result: Hypertension")
            healthTip = ("Health Tip: Consult doctor for medication tab 💊")
            bloodPressure = ("Blood Pressure: \(systolic)/\(diastolic) mm Hg")
            mBP = ("MBP: \(MBP)")
            image = "hypertension"
            
        }

        
        
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
            if(segue.identifier == "resultSegue")
            {
                let destination = segue.destination as! ResultViewController
                destination.image = image
                destination.mBP = mBP
                destination.result = result
                destination.healthTip = healthTip
                destination.bloodPressure = bloodPressure
                destination.patientID = patientID
            }
    }
    
    
    

}

