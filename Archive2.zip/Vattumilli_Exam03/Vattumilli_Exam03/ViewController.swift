//
//  ViewController.swift
//  Vattumilli_Exam03
//
//  Created by Bala Venkata Sai Kishore Vattumilli on 4/18/24.
//

import UIKit

class Animal{
    var AnimalName:String?
    var Description:String?
    var image:String?
    
    init(AnimalName: String? = nil, Description: String? = nil, image: String? = nil) {
        self.AnimalName = AnimalName
        self.Description = Description
        self.image = image
    }
}


class VattumilliHomeViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return animals.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "VattumilliCell", for: indexPath)
      
        cell.textLabel?.text = animals[indexPath.row].AnimalName
        return cell
    }
    

    
    @IBOutlet weak var VattumilliTVOL: UITableView!
    
    var animals = [Animal]()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.title = "Animals"
        VattumilliTVOL.delegate = self
        VattumilliTVOL.dataSource = self
        
        
        let A1 = Animal(AnimalName: "Lion", Description: "Lions have strong, compact bodies and powerful forelegs, teeth and jaws for pulling down and killing prey.", image: "Lion")
        animals.append(A1)
        
        let A2 = Animal(AnimalName: "Elephant", Description: "Elephants are the largest land mammals in the world, with adult males weighing up to 7 tons and females weighing up to 8,000 pounds. ", image: "Elephant")
        animals.append(A2)
        
        let A3 = Animal(AnimalName: "Tiger", Description: "Tigers are the largest members of the cat family, and are the second strongest animal after lions.", image: "Tiger")
        animals.append(A3)
        
        
        let A4 = Animal(AnimalName: "Giraffe", Description: "The giraffe is also well known for the unique brown and white pattern on its coat (“pelage”) and its lengthy eyelashes and legs.", image: "Giraffe")
        animals.append(A4)
        
        let A5 = Animal(AnimalName: "Zebra", Description: "Zebras are African mammals with black and white stripes. They are herbivores that primarily eat grass, but will also eat other plants if grass is scarce.", image: "Zebra")
        animals.append(A5)
        
        let A6 = Animal(AnimalName: "Panda", Description: "Giant pandas have a distinctive black and white coat, with black fur around their eyes and on their ears, muzzle, legs and shoulders.", image: "Panda")
        animals.append(A6)
        
        let A7 = Animal(AnimalName: "Koala", Description: "Koalas are marsupials with thick bodies, small eyes, and large ears.", image: "Koala")
        animals.append(A7)
        
        let A8 = Animal(AnimalName: "Dolphin", Description: "Dolphins are small-toothed mammals with smooth, rubbery skin. They have a streamlined body, a long, slender snout, and about 100 teeth.", image: "Dolphin")
        animals.append(A8)
        
        let A9 = Animal(AnimalName: "Penguin", Description: "Penguins are flightless birds that live in the Southern Hemisphere.", image: "Penguin")
        animals.append(A9)
        
        let A10 = Animal(AnimalName: "Polar Bear", Description: "Polar bears are the largest land carnivores on Earth, with males weighing up to 1,700 lbs and standing over 11 ft tall", image: "PolarBear")
        animals.append(A10)
        
        let A11 = Animal(AnimalName: "Kangaroo", Description: "Kangaroos are the world's largest marsupials, and can grow to be 3–8 feet tall and weigh 40–200 pounds. ", image: "Kangaroo")
        animals.append(A11)
        
        let A12 = Animal(AnimalName: "Gorilla", Description: "Gorillas are the largest of the great apes, with broad chests and shoulders, large hands, and small eyes set into hairless faces.", image: "Gorilla")
        animals.append(A12)
        
        let A13 = Animal(AnimalName: "Wolf", Description: "Wolves are the largest wild canine. They have long legs, large skulls, and big jaws that help them catch and eat large mammals.", image: "Wolf")
        animals.append(A13)
        
        let A14 = Animal(AnimalName: "Cheetah", Description: "Cheetahs have slender, long-legged bodies with blunt, semi-retractable claws.", image: "Cheetahs")
        animals.append(A14)
        
        let A15 = Animal(AnimalName: "Crocadile", Description: "Crocodiles have powerful jaws with many conical teeth and short legs with clawed webbed toes.", image: "Crocadile")
        animals.append(A15)
        
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let value = sender as? Int,
           let destinationVC = segue.destination as? VattumilliAnimalController {
            destination.animal = animals[(VattumilliTVOL.indexPathForSelectedRow?.row)!]
        }
    }



}

