//
//  ViewController.swift
//  Vattumilli_TravelBooking
//
//  Created by Bala Venkata Sai Kishore Vattumilli on 3/27/24.
//

import UIKit

class BookingViewController: UIViewController {
    
    var image = ""
    var greetings = ""
    var classtype = ""
    var total = 0.0
    var travellers = ""
    var name = ""

    
    @IBOutlet weak var travellerNameOL: UITextField!
    
    
    @IBOutlet weak var noOfTravellersOL: UITextField!
    
    @IBOutlet weak var cabinTypeOL: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        
    }
    
    @IBAction func bookNowButton(_ sender: Any) {
        
        name = travellerNameOL.text ?? ""
        
                travellers = noOfTravellersOL.text ?? ""
                classtype = cabinTypeOL.text?.lowercased() ?? ""
        print(classtype)
        if(classtype == "economy"){
            total = Double(travellers)! * 125
                            image = "economy"
            
            
        }
        else if(classtype == "luxury")
        {
            
            total = Double(travellers)! * 200
                            image = "luxury"
            
        }
        else
        {
            image = "wrong"
           // print(image)
                        name = ""
                        travellers = ""
                        classtype = ""
                        total = 0.0
                        performSegue(withIdentifier: "resultSegue", sender: self)
            
            
        }
        
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
            if(segue.identifier == "resultSegue")
            {
                let destination = segue.destination as! ResultViewController
                destination.image = image
                destination.classtype = classtype
                destination.travellers = travellers
                destination.total = total
                destination.name = name
            }
    }
    

}

