//
//  ResultViewController.swift
//  Vattumilli_TravelBooking
//
//  Created by Bala Venkata Sai Kishore Vattumilli on 3/27/24.
//

import UIKit

class ResultViewController: UIViewController {

    
    @IBOutlet weak var imageOL: UIImageView!
    
    @IBOutlet weak var resultOL: UILabel!
    
    
    @IBOutlet weak var travellerNameOL: UILabel!
    
    
    @IBOutlet weak var noOfTravellersOL: UILabel!
    
    
    @IBOutlet weak var cabinTypeOL: UILabel!
    
    
    
    @IBOutlet weak var totalCostOL: UILabel!
    
    
    var image = ""
    var name = ""
    var travellers = ""
    var classtype = ""
    var total = 0.0
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if(image == "wrong"){
            image = "invalid"
            imageOL.image = UIImage(named: image)
            resultOL.text = "There is no selected class. Please choose a valid class."
            
            
        }else{
            imageOL.image = UIImage(named: image)
            resultOL.text = "Hello \(name), your Booking is Confirmed"
            travellerNameOL.text = "Name: \(name)"
            //print(name)
            noOfTravellersOL.text = "Number of Travellers: \(travellers)"
            cabinTypeOL.text = "Cabin Class: \(classtype.capitalized)"
            totalCostOL.text = "Total Cost: $\(total)"
        }
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
