import UIKit

var greeting = "Hello, playground"
var fact = "Swift is a type safe language"
var dev = "Development of swift began in 2010"
var author = "Swift was created by Chris Lattner"
var count:Int = fact.count
print("\(greeting)")


print(count)
fact += ", it has a better management"
dev.append(" by Apple")
print("\(fact)")
print("\(dev)")

// lower cased
print("lowercased letters of author variable: \(author.lowercased())")

//Upper cased
print("Uppercased:\(author.uppercased())")

print("Starting character in author: \(author[author.startIndex])")

print("\(author[author.index(before: author.endIndex)])")

print("\(dev[dev.startIndex])")

print("\(dev[dev.index(before:author.endIndex)])")

print("\(author[author.index(after:author.startIndex)])")

print("\(author[author.index(author.startIndex,offsetBy: 5)])")

print("\(fact[fact.index(fact.endIndex, offsetBy: -4)])")


//Strings 02

var shoppingList = "The  shopping list contains: "
var foodItems = "Cheese, Butter, Chocolate Spread"
var clothes = "Socks, T-shirts"


if(clothes.hasPrefix("Socks"))
{
    print("The first item in clothes is socks")
}else{
    print("socks is not the first item in clothes")
}
// seperator

print(foodItems.split(separator: ","))

if(clothes.contains(",")){
    print("Clothes contains more than one Item")
    
}else{
    print("Clothes contains only one item")
}
print("\(foodItems[foodItems.startIndex..<foodItems.index(foodItems.endIndex,offsetBy: -7)])")

shoppingList += foodItems[foodItems.index(foodItems.startIndex, offsetBy: 8)..<foodItems.endIndex]
print("\(shoppingList)")

print(clothes.remove(at: clothes.firstIndex(of: "T")!))
print("\(clothes)")
var course = "44643-Mobile Computing-iOS"
print("\(course[course.startIndex..<course.index(course.startIndex, offsetBy: 5)])")
