//
//  ViewController.swift
//  BMIApp
//
//  Created by Bala Venkata Sai Kishore Vattumilli on 3/26/24.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var weightOL: UITextField!
    
    @IBOutlet weak var heightOL: UITextField!
    
    var height = 0.0
    var weight = 0.0
    var bmi = 0.0
    var result = ""
    var image = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


    @IBAction func CalcBMI(_ sender: Any) {
        
        // Read the height and weight convert it to double
        
         height = Double(heightOL.text!)!
         weight = Double(weightOL.text!)!
        //calculate the bmi
        //bmi = (703*weight)/(height*height)
        
         bmi = (703*weight)/(height*height)
        
        if(bmi<18.8){
            result = "underweight"
            image = "underweight"
        }
        else if(bmi<25){
            result = "normal"
            image = "healthy"
        }
        else if(bmi < 30)
        {
            result = "overweight"
            image = "overweight"
            
        }
        else{
            result = "obese"
            image = "obese"
        }
        
        
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
        if(segue.identifier == "BmiSegue"){
            let destination = segue.destination as! ResultViewController
            
            // assigning view controller values to result view controller
            
            destination.image = image
            destination.height = height
            destination.weight = weight
            destination.result = result
            destination.bmi = bmi
            
            
        }
    }
    
}

