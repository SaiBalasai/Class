//
//  ViewController.swift
//  AnimationsDemo
//
//  Created by Vattumilli,Bala Venkata Sai Kishore on 3/7/24.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var imageViewOL: UIImageView!
    
    
    
    @IBOutlet weak var showMeOL: UIButton!
    
    
    @IBOutlet weak var happyOL: UIButton!
    
    @IBOutlet weak var sadOL: UIButton!
    
    @IBOutlet weak var angryOL: UIButton!
    
    @IBOutlet weak var shakeMeOL: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    override func viewDidAppear(_ animated: Bool) {
        //keep all the components except show me out side of the view/screen
        
        imageViewOL.frame.origin.x = view.frame.width
        happyOL.frame.origin.x = view.frame.width
        sadOL.frame.origin.x = view.frame.width
        angryOL.frame.origin.x = view.frame.width
        shakeMeOL.frame.origin.x = view.frame.width
        
    }
        
    @IBAction func happyButtonClicked(_ sender: Any) {
        
        updateAndAnimate("happy")
        
        
    }
    
    @IBAction func sadButtonClicked(_ sender: Any) {
        updateAndAnimate("sad")
    }
    
    
    @IBAction func angryButtonClicked(_ sender: Any) {
        updateAndAnimate("angry")
    }
    
    
    @IBAction func shakeMeButtonClicked(_ sender: Any) {
        
        // when we click the button wee need to increase the image size
        
        var width = imageViewOL.frame.width
        width += 40
        var height = imageViewOL.frame.height
        height += 40
        
        var x = imageViewOL.frame.origin.x
        x-=20
        
        var y = imageViewOL.frame.origin.y
        
        y-=20
        
        var largeFrame = CGRect(x: x, y: y, width: width, height: height)
        
        //animation
        
        UIView.animate(withDuration: 1, delay: 0, usingSpringWithDamping: 0.5, initialSpringVelocity: 50, animations: {
            self.imageViewOL.frame = largeFrame
        })
        
        
        
    }
    
    
    @IBAction func showMeButtonClicked(_ sender: Any) {
        
        
        //move all the components to the outside of the view to center
        UIView.animate(withDuration: 1, animations: {self.imageViewOL.center.x=self.view.center.x
            self.happyOL.center.x=self.view.center.x
            self.sadOL.center.x=self.view.center.x
            self.angryOL.center.x=self.view.center.x
            self.shakeMeOL.center.x=self.view.center.x
            
            
            
        })
        
        //disable the show me button
        showMeOL.isEnabled=false
    }
    
    
    func updateAndAnimate(_ image:String)
    {
        
        // making the current image as opaque(alpha = 0)
        
        UIView.animate(withDuration: 1, animations: {
            self.imageViewOL.alpha = 0
        })
        
        //assign the new image with an animation make it transparent(alpha=1)
        UIView.animate(withDuration: 1, delay: 0.5, animations: {
            self.imageViewOL.alpha = 1
            self.imageViewOL.image = UIImage(named: image)
        })
        
    }
    
}

