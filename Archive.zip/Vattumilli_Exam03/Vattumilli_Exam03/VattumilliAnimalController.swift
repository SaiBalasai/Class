//
//  VattumilliAnimalController.swift
//  Vattumilli_Exam03
//
//  Created by Bala Venkata Sai Kishore Vattumilli on 4/18/24.
//

import UIKit

class VattumilliAnimalController: UIViewController {

    
    @IBOutlet weak var imageViewOL: UIImageView!
    
    
    @IBOutlet weak var nameOL: UILabel!
    
    
    @IBOutlet weak var descriptionOL: UITextView!
    var animal:Animal?
    override func viewDidLoad() {
        super.viewDidLoad()
        imageViewOL.image = UIImage(named: animal?.image ?? "")
        
        nameOL.text = "\((animal?.AnimalName)!)"
        
        descriptionOL.text = "\((animal?.Description)!)"

        // Do any additional setup after loading the view.
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        UIView.animate(withDuration: 2, delay: 1, animations: {self.imageViewOL.alpha = 0
                        self.imageViewOL.alpha = 1
            self.imageViewOL.image = UIImage(named: imageName)

    }
                       func showInfoAction(_ sender: UIButton) {
                           if let selectedAnimal = selectedAnimals {
                                       descriptionOL.text = selectedAnimal.information
                                   }
                       }
                   }
                       
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
