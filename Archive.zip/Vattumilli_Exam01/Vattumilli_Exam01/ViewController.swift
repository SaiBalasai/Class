//
//  ViewController.swift
//  Vattumilli_Exam01
//
//  Created by Bala Venkata Sai Kishore Vattumilli on 3/19/24.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var patientID: UITextField!
    
    
    @IBOutlet weak var fBGValue: UITextField!
    
    @IBOutlet weak var outputOL: UILabel!
    
    
    @IBOutlet weak var imageViewOL: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func CalculateHb1A1cButton(_ sender: Any) {
        
        var patientID = Int(patientID.text!)
        
        var inputFBGValue = Double(fBGValue.text!)
        
        var HbA1c = Double(2.6 + 0.03 * inputFBGValue!)
        
        if (Double(inputFBGValue!) >= 0 && Double(inputFBGValue!) <= 69 && Double(HbA1c) <= 4.70){
            outputOL.text! = "Patient ID: \(patientID)\nFBG Level: \(inputFBGValue)(mg/dl)\nHbA1c(%): \(HbA1c)%\nResult: Hypoglycemia\nHealth Tip: Eat Food on Time 🍎"
            imageViewOL.image = UIImage(named: "hypoglycemia.png")
        } else if (Double(inputFBGValue!) >= 70 && Double(inputFBGValue!) <= 99 && Double(HbA1c) >= 4.70 && Double(HbA1c) <= 5.59){
            outputOL.text! = "Patient ID : \(patientID) \n\n FBG Level : \(inputFBGValue)(mg/dl) \n\n HbA1c(%) : \(HbA1c)% \n\n Result : Normal \n\n Health Tip: You are doing great👍"
            imageViewOL.image = UIImage(named: "normal.png")
        }
        else if (Double(inputFBGValue!) >= 100 && Double(inputFBGValue!) <= 125 && Double(HbA1c) >= 5.60 && Double(HbA1c) <= 6.35){
            outputOL.text! = "Patient ID : \(patientID) \n\n FBG Level :\(inputFBGValue)(mg/dl) \n\n HbA1c(%) : \(HbA1c)% \n\n Result : Pre-Diabetes \n\n Health Tip: You should work on your diet and maintain workout🏋️‍♀️"
            imageViewOL.image = UIImage(named: "pre-diabetes.png")
        }
        else if (Double(inputFBGValue!) >= 126 && Double(HbA1c) >= 6.35){
            outputOL.text! = "Patient ID : \(patientID) \n FBG Level : \(inputFBGValue) (mg/dl) \n\n HbA1c(%) : \(HbA1c)% \n\n Result : Diabetes \n Health Tip: Consult doctor for medication🩺"
            imageViewOL.image = UIImage(named: "diabetes.png")
            
            
        }
    }
    @IBAction func ResetBTN(_ sender: Any) {
        imageViewOL.image = UIImage(named:" ")
        outputOL.text = " "
        patientID.text = " "
        fBGValue.text = " "
    }
    
    

}

