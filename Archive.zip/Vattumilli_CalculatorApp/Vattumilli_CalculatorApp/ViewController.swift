//
//  ViewController.swift
//  Vattumilli_CalculatorApp
//
//  Created by Bala Venkata Sai Kishore Vattumilli on 2/4/24.
//

    
import UIKit

class ViewController: UIViewController {

var curInp: Double = 0;
 var prevInp: Double = 0
 var currOpe: String = ""
 var isNumb = false
 var isNeg = false

 @IBOutlet weak var resultOutlet: UILabel!
 
 
 @IBAction func btnAllClear(_ sender: UIButton) {
     curInp = 0
     prevInp = 0
     currOpe = ""
     resultOutlet.text = " "
     isNumb = false
     isNeg = false
     
 }
 
 
 @IBAction func btnClr(_ sender: UIButton) {
     
     resultOutlet.text = "0"
     isNumb = false
 }
 
 
 
 @IBAction func btnAddorSub(_ sender: UIButton) {
     
     if isNumb{
         
         isNeg = !isNeg
         if isNeg{
             resultOutlet.text = "-" + resultOutlet.text!
         }else{
             resultOutlet.text!.removeFirst()
         }
     }
     
 }
 
 
 @IBAction func btnDivison(_ sender: UIButton) {
     calculatedOpe("÷")
 }
 
 
 
 
 @IBAction func btnMultiply(_ sender: UIButton) {
     
     calculatedOpe("X")
 }
 
 @IBAction func btnSub(_ sender: UIButton) {
     
     calculatedOpe("-")
 }
 
 
 @IBAction func btnAdd(_ sender: UIButton) {
     
     calculatedOpe("+")
 }
 
 @IBAction func btnEqual(_ sender: UIButton) {
     
     if isNumb {
         let input1  = Double(resultOutlet.text!) ??  0
         switch currOpe{
         case "+":
             curInp += input1
         
         case "-":
             curInp -= input1
             
         case "X":
             curInp *= input1
             
         case "÷":
             if input1 != 0 {
                 curInp /= input1
             } else {
                 resultOutlet.text = "Not a number"
                 return
             }
         case "%":
             curInp = curInp.truncatingRemainder(dividingBy: input1)
         default:
             break
         }
         resultOutlet.text = finalResult(curInp)
         
         isNumb = false
         isNeg = false
     }
 }
 
 
 @IBAction func btnModulus(_ sender: UIButton) {
     calculatedOpe("%")
 }
 
 @IBAction func btnDecimal(_ sender: UIButton) {
     
     if isNumb && !resultOutlet.text!.contains("."){
         resultOutlet.text! += "." }
     else if !isNumb{
         resultOutlet.text = "."
         isNumb = true
         
     }
 }
    
 @IBAction func numbSeven(_ sender: UIButton) {
     calculatedDigit(7)

 }
 @IBAction func numbEight(_ sender: UIButton) {
     calculatedDigit(8)

 }
 @IBAction func numbNine(_ sender: UIButton) {
     calculatedDigit(9)

 }
 @IBAction func numbFour(_ sender: UIButton) {
     calculatedDigit(4)

 }
 @IBAction func numbFive(_ sender: UIButton) {
     calculatedDigit(5)

 }
 @IBAction func numbSix(_ sender: UIButton) {
     calculatedDigit(6)

 }
 @IBAction func numbOne(_ sender: UIButton) {
     calculatedDigit(1)

 }
 @IBAction func numbTwo(_ sender: UIButton) {
     calculatedDigit(2)

 }
 @IBAction func numbThree(_ sender: UIButton) {
     calculatedDigit(3)

 }
 @IBAction func numZero(_ sender: UIButton) {
     calculatedDigit(0)

 }

 override func viewDidLoad() {
     
     super.viewDidLoad()
     // Do any additional setup after loading the view.
     
 }
 
 func calculatedDigit(_ number: Int) {
     if isNumb {
         if resultOutlet.text == "0" || resultOutlet.text == "-0" {
             if number != 0 {
                 resultOutlet.text = isNeg ? "-" + "\(number)" : "\(number)"
             }
         }else {
             resultOutlet.text! += "\(number)"
         }
     }else {
         resultOutlet.text = isNeg ? "-" + "\(number)":"\(number)"
         isNumb = true
         
             }
         }
 
 func calculatedOpe(_ operatorSign : String) {
     if isNumb{
         let currentInp = resultOutlet.text!
         curInp = Double(currentInp) ?? 0
         isNumb = false
     }
     currOpe = operatorSign
     isNeg = false
 }
 
 func finalResult(_ number1: Double) -> String{
 let roundNumber = round(number1 * 100000) / 100000
     if roundNumber.truncatingRemainder(dividingBy: 1) == 0 {
         return String(format: "%.0f" , roundNumber)
     } else {
         return String(roundNumber);
     }
 }
}


    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
