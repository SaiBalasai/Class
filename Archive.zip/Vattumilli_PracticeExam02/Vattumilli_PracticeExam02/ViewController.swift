//
//  ViewController.swift
//  Vattumilli_PracticeExam02
//
//  Created by Bala Venkata Sai Kishore Vattumilli on 4/9/24.
//

import UIKit

class ViewController: UIViewController {
    
    
    var type = ""
    var loanAmount = 0.0
    var interestRate = 0.0
    var term = 0.0
    var image = ""
    var totalMonths = 0.0
    var monthlyInterestRate = 0.0
    var monthlyEMI = 0.0
    
    
    @IBOutlet weak var loanTypeOL: UITextField!
    
    
    @IBOutlet weak var loanAmountOL: UITextField!
    
    
    @IBOutlet weak var interestRateOL: UITextField!
    
    @IBOutlet weak var calculateEMIOL: UIButton!
    
    @IBOutlet weak var ResetOL: UIButton!
    
    @IBOutlet weak var totalMonthsOL: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        ResetOL.isEnabled = false
        calculateEMIOL.isEnabled = false
       
        // Do any additional setup after loading the view.
    }
    
    


    @IBAction func caluclateEMIBTN(_ sender: Any) {
        
        type = loanTypeOL.text!
        loanAmount = Double(loanAmountOL.text!)!
        interestRate = Double(interestRateOL.text!)!
        term = Double(totalMonthsOL.text!)!
        let loanType = loanTypeOL.text!
      
      
        if(type.lowercased() == "car"){
            totalMonths = (term * 12)
             monthlyInterestRate = (interestRate/12)/100
             monthlyEMI = loanAmount * (monthlyInterestRate * pow(1 + monthlyInterestRate,totalMonths))/(pow(1 + monthlyInterestRate,totalMonths) - 1)
            image = "car"
        }
        else if(type.lowercased() == "home")
        {
            totalMonths = (term * 12)
             monthlyInterestRate = (interestRate/12)/100
             monthlyEMI = loanAmount * (monthlyInterestRate * pow(1 + monthlyInterestRate,totalMonths))/(pow(1 + monthlyInterestRate,totalMonths) - 1)
            image = "home"
            
        }
        else
        {
            totalMonths = (term * 12)
             monthlyInterestRate = (interestRate/12)/100
             monthlyEMI = loanAmount * (monthlyInterestRate * pow(1 + monthlyInterestRate,totalMonths))/(pow(1 + monthlyInterestRate,totalMonths) - 1)
            image = "personal"
        }
        
        
        
      
        
    }
    
    
    @IBAction func ResetBTN(_ sender: Any) {
        
        term = 0
        interestRate = 0.0
        loanAmount = 0.0
        type = ""
        
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
        if(segue.identifier == "Result"){
            let destination = segue.destination as! ResultViewController
            
            // assigning view controller values to result view controller
            
            destination.image = image
            destination.loanAmount = loanAmount
            destination.type = type
            destination.interestRate = interestRate
            destination.monthlyEMI=monthlyEMI
            
            
        }
    }
    
    

    
}

