//
//  ViewController.swift
//  Vattumilli_MovieApp
//
//  Created by Bala Venkata Sai Kishore Vattumilli on 4/4/24.
//

import UIKit


class MoviesViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return Movie.genreList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "genreCell", for: indexPath)
        cell.textLabel?.text = Movie.genreList[indexPath.row]
        return cell
    }

    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        performSegue(withIdentifier: "listsSegue", sender: indexPath.row)
    }
    
    
    @IBOutlet weak var genreTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.title = "Movies"

        genreTableView.delegate = self
        genreTableView.dataSource = self
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let value = sender as? Int,
           let destinationVC = segue.destination as? MovieListViewController {
            destinationVC.selectedGenre = Movie.genreList[value]
        }
    }


}

