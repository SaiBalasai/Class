//
//  MovieInfoViewController.swift
//  Vattumilli_MovieApp
//
//  Created by Bala Venkata Sai Kishore Vattumilli on 4/6/24.
//

import UIKit

class MovieInfoViewController: UIViewController {

    @IBOutlet weak var movieImageViewOutlet: UIImageView!
    
    @IBOutlet weak var movieInfoOutlet: UITextView!
    
    var selectedMovie: MovieList?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if let selectedMovie = selectedMovie {
            self.title = selectedMovie.movieName
            movieImageViewOutlet.image = UIImage(named:selectedMovie.movieImage!)
            movieInfoOutlet.text = ""
                }

    }
   
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        var width = movieImageViewOutlet.frame.width
        width += 40
        var height = movieImageViewOutlet.frame.height
        height += 40
        
        var x = movieImageViewOutlet.frame.origin.x
        x-=20
        
        var y = movieImageViewOutlet.frame.origin.y
        
        y-=20
        
        var largeFrame = CGRect(x: x, y: y, width: width, height: height)
        
        //animation
        
        UIView.animate(withDuration: 1, delay: 0, usingSpringWithDamping: 0.5, initialSpringVelocity: 50, animations: {
            self.movieImageViewOutlet.frame = largeFrame
        })
    }
    
  

    
    @IBAction func showInfoAction(_ sender: UIButton) {
        if let selectedMovie = selectedMovie {
                    movieInfoOutlet.text = selectedMovie.movieInfo
                }
    }
}
    



