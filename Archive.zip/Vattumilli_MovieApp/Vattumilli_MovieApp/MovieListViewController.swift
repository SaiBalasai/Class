//
//  MovieListViewController.swift
//  Vattumilli_MovieApp
//
//  Created by Bala Venkata Sai Kishore Vattumilli on 4/6/24.
//

import UIKit

class MovieListViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    var selectedGenre: String?
    var movies:[MovieList] = []
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return movies.count
    }
    
        func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            let cell = tableView.dequeueReusableCell(withIdentifier: "listCell", for: indexPath)
            cell.textLabel?.text = movies[indexPath.row].movieName
            return cell
        }
        
        
        func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
            performSegue(withIdentifier: "movieInfoSegue", sender: indexPath.row)
        }
        
        @IBOutlet weak var movieListTableView: UITableView!
        
        override func viewDidLoad() {
            super.viewDidLoad()
            if let view = selectedGenre {
                self.title = view
                movies = Movie.movieData[view] ?? []
            }
            movieListTableView.dataSource = self
            movieListTableView.delegate = self
            // Do any additional setup after loading the view.
        }
        
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let index = sender as? Int,
           let destinationVC = segue.destination as? MovieInfoViewController {
            destinationVC.selectedMovie = movies[index]
        }
    }

    
    }

