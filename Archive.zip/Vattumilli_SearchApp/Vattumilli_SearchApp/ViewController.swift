//
//  ViewController.swift
//  Vattumilli_SearchApp
//
//  Created by Bala Venkata Sai Kishore Vattumilli on 3/17/24.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var SearchTextField: UITextField!
    
    @IBOutlet weak var resultImage: UIImageView!
    
    @IBOutlet weak var search: UIButton!
    
    
    @IBOutlet weak var topicInfoText: UITextView!
    
    
    @IBOutlet weak var nextButton: UIButton!
    
    @IBOutlet weak var prevButton: UIButton!
    
    @IBOutlet weak var resetButton: UIButton!
    
    
    let topicImages = [
        ["ntr", "surya", "nagarjuna", "venkatesh", "ram"],
        ["lion", "tiger", "camel", "horse", "cat"],
        ["tulip", "rose", "lotus", "jasmine", "lavender"]
    ]
    
    let actorsKeywords = ["actor", "movie", "hero", "film"]
    let animalsKeywords = ["animal", "wildlife", "pet"]
    let flowersKeywords = ["flower", "floral", "garden"]
    
    let topics_array = [
        "Actors": [
            "ntr": "This is an image of NTR.",
            "surya": "This is an image of Surya.",
            "nagarjuna": "This is an image of Nagarjuna.",
            "venkatesh": "This is an image of Venkatesh.",
            "ram": "This is an image of Ram."
        ],
        "Animals": [
            "lion": "This is an image of a Lion.",
            "tiger": "This is an image of a Tiger.",
            "camel": "This is an image of a Camel.",
            "horse": "This is an image of a Horse.",
            "cat": "This is an image of a Cat."
        ],
        "Flowers": [
            "tulip": "This is an image of a Tulip.",
            "rose": "This is an image of a Rose.",
            "lotus": "This is an image of a Lotus.",
            "jasmine": "This is an image of Jasmine.",
            "lavender": "This is an image of Lavender."
        ]
    ]
    
    
    
    var topic: Int?
    var currentIndex: Int = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        displayWelcomeImage()
         disableButtons()
    }
    
    func displayWelcomeImage() {
           resultImage.image = UIImage(named: "welcome")
       }
       
       func displayNotFoundImage() {
           resultImage.image = UIImage(named: "notfound")
       }
       
       func disableButtons() {
           nextButton.isEnabled = false
           prevButton.isEnabled = false
       }
       
       func enableButtons() {
           nextButton.isEnabled = true
           prevButton.isEnabled = true
       }
    
       
    @IBAction func SearchButtonAction(_ sender: Any) {
        //guard let searchText = SearchTextField.text?.lowercased() else { return }
        
        
        guard let searchText = SearchTextField.text?.lowercased() .trimmingCharacters(in: .whitespacesAndNewlines), !searchText.isEmpty  else {
               displayWelcomeImage()
               disableButtons()
               return
           }
           if searchText.containsKeywords(from: actorsKeywords) {
               topic = 0
            //search.isEnabled = true
            
               displayImages()
           } else if searchText.containsKeywords(from: animalsKeywords) {
               topic = 1
               //search.isEnabled = true
               displayImages()
           } else if searchText.containsKeywords(from: flowersKeywords) {
               topic = 2
               //search.isEnabled = true
               displayImages()
           } else {
               displayNotFoundImage()
               disableButtons()
               //search.isEnabled = true
           }
            }
    
    func displayImages() {
        guard let topic = topic else { return }
        
        let topicNames = Array(topics_array.keys)
        guard topic < topicNames.count else { return }
        
        let topicName = topicNames[topic]
        let imageName = topicImages[topic][currentIndex] // Get the current image name
        
        resultImage.image = UIImage(named: imageName)
        
        // Fetch the description corresponding to the current image
        if let topicDictionary = topics_array[topicName],
           let imageDescription = topicDictionary[imageName] {
            topicInfoText.text = imageDescription
        } else {
            // Handle the case where the description is not found
            topicInfoText.text = "Description not available"
        }
        
        enableButtons()
        nextButton.isHidden = false
        prevButton.isHidden = false
        resetButton.isHidden = false
        prevButton.isEnabled = false
    }

    
    @IBAction func ShowPrevImageButtons(_ sender: Any) {
        guard let topic = topic else { return }
           currentIndex = (currentIndex - 1 + topicImages[topic].count) % topicImages[topic].count
           displayImages()
        prevButton.isEnabled = true
        if(currentIndex == 0){
            prevButton.isEnabled = false
        }
        
    }
    
    @IBAction func ResetBtn(_ sender: Any) {
        resultImage.image = UIImage(named: "welcome")
          topicInfoText.text = ""
          SearchTextField.text = ""
          currentIndex = 0
          disableButtons()
          nextButton.isHidden = true
          prevButton.isHidden = true
          resetButton.isHidden = true
        
    }

    
    @IBAction func ShowNextImagesBtn(_ sender: Any) {
        guard let topic = topic else { return }
         currentIndex = (currentIndex + 1) % topicImages[topic].count
         displayImages()
        prevButton.isEnabled = true
        if(currentIndex == 4){
            nextButton.isEnabled = false
        }
    }
}
    extension String {
        func containsKeywords(from keywords: [String]) -> Bool {
            for keyword in keywords {
                if self.contains(keyword.lowercased()) {
                    return true
                }
            }
            return false
        }
        
        
        
    
}

