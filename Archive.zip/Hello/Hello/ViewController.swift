//
//  ViewController.swift
//  Hello
//
//  Created by Bala Venkata Sai Kishore Vattumilli on 1/23/24.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var input: UITextField!
    
    @IBOutlet weak var output: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func submitBtn(_ sender: Any) {
        var ip = input.text!
        output.text = "Hello \(ip)"
    }
    
}

