//
//  ViewController.swift
//  Vattumilli_Assignment02
//
//  Created by Bala Venkata Sai Kishore Vattumilli on 1/30/24.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var nameOutlet: UITextField!
    
    @IBOutlet weak var billAmountOutlet: UITextField!
    
    @IBOutlet weak var tipPercentageOutlet: UITextField!
    
    @IBOutlet weak var dateOutlet: UIDatePicker!
    
    
    @IBOutlet weak var dateLabel: UILabel!
    
    @IBOutlet weak var nameLabel: UILabel!
    
    @IBOutlet weak var billAmountLabel: UILabel!
    
    @IBOutlet weak var tipAmountLabel: UILabel!
    
    
    @IBOutlet weak var totalAmountLabel: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func SubmitBTN(_ sender: Any) {
        
        var name = nameOutlet.text!
        nameLabel.text = name
        
        var bill = Double(billAmountOutlet.text!)
        billAmountLabel.text! = "$\(String(bill!))"
        
        var tip = Int(tipPercentageOutlet.text!)
        tipAmountLabel.text! = "$\(String(tip!))"
        
        
        var total = Int(bill!) + Int(tip!)
        totalAmountLabel.text! = "$\(String(total))"
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        let date = Date()
        let dateString = dateFormatter.string(from: date)
         dateLabel.text = dateString
    }
    
    @IBAction func ResetBTN(_ sender: Any) {
        
        nameLabel.text! = " "
        billAmountLabel.text! = " "
        tipAmountLabel.text! = " "
        totalAmountLabel.text = " "
        dateLabel.text! = " "
        
    }
    
    


}

