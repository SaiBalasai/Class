//
//  ViewController.swift
//  CollectionViewDemo
//
//  Created by Bala Venkata Sai Kishore Vattumilli on 4/2/24.
//

import UIKit

class ViewController: UIViewController, UICollectionViewDataSource, UICollectionViewDelegate {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return movies.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = movieCollectionViewOL.dequeueReusableCell(withReuseIdentifier: "reusableCell", for: indexPath) as! MovieCollectionViewCell
        
        cell.assignMovie(with: movies[indexPath.row])
        return cell
        
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        //Assign Movie Details(Title,Year,BoxOffice,Ratings)
        assignMovieDetails(index: indexPath)
        
        
    }
    func assignMovieDetails(index: IndexPath)
    {
        titleOL.text = movies[index.row].title
        ratingOL.text = movies[index.row].movieRating
        boxOfficeOL.text = movies[index.row].boxOffice
        yearReleasedOL.text = movies[index.row].releasedYear
    }
    
    @IBOutlet weak var titleOL: UILabel!
    
    
    @IBOutlet weak var yearReleasedOL: UILabel!
    
    
    @IBOutlet weak var boxOfficeOL: UILabel!
    
    
    @IBOutlet weak var ratingOL: UILabel!
    
    
    @IBOutlet weak var movieCollectionViewOL: UICollectionView!
   
   
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        movieCollectionViewOL.dataSource = self
        movieCollectionViewOL.delegate = self
    }
    


}

