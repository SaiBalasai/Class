//
//  ViewController.swift
//  Vattumilli_WordGuess
//
//  Created by Bala Venkata Sai Kishore Vattumilli on 3/4/24.
//

import UIKit

class ViewController: UIViewController {
    
    var presebtguess: String = ""
          var currentGuess: Bool = false
          var gameLEVL: Int = 0
          var remsining = 5
          var wordsfound = 0
          var temp = false
          var isReset = false
          var aimword = ""
          var correctCount = 0
          var loadedstring = ""
          var noofattempts = 0
          var findword = ""
          var inputstr = ""
        var maxnoofattempts = 10
        
        var cityguesswords = [["newyork", "The city that never sleeps", "newyork"],
                      ["paris", "The city of love", "paris"],
                      ["tokyo", "Capital of Japan", "tokyo"],
                      ["sydney", "Harbor city in Australia", "sydney"],
                      ["cairo", "Capital of Egypt", "cairo"]]
    @IBOutlet weak var wordsGuessedLabel: UILabel!
    
    @IBOutlet weak var wordsRemainingLabel: UILabel!
    
    @IBOutlet weak var totalWordsLabel: UILabel!
    
    @IBOutlet weak var userGuessLabel: UILabel!

    @IBOutlet weak var characterEntered: UITextField!
    
    @IBOutlet weak var hintLabel: UILabel!
    
    @IBOutlet weak var guessCountLabel: UILabel!
    
    @IBOutlet weak var statusLabel: UILabel!
    
    
    @IBOutlet weak var guessBtn: UIButton!
    
    
    
    @IBOutlet weak var playAgainBtn: UIButton!
    
    
    @IBOutlet weak var guessletterField: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        updateUser(l: gameLEVL)
                     
                     guessCountLabel.text = "You have made 0 guesses"
                     statusLabel.isEnabled = false
                     playAgainBtn.isHidden = true
                     playAgainBtn.isEnabled = false
                     guessBtn.isEnabled = false
                     guessletterField.addTarget(self, action: #selector(CharEntered(_:)), for: .editingChanged)
    }
    
    
    @IBAction func guessLetterButtonPressed(_ sender: UIButton) {
        
        playAgainBtn.isHidden = true
                       playAgainBtn.isEnabled = false
                       
                       if (noofattempts < maxnoofattempts && remsining > 0) {
                           inputstr = ""
                           inputstr = guessletterField.text!
                           let lastIndex = inputstr.index(before: inputstr.endIndex)
                           let lastCharacter = inputstr[lastIndex]
                           aimword.append(lastCharacter)
                           noofattempts += 1
                           
                           loadedstring = ""
                           findword = cityguesswords[gameLEVL][0].uppercased()
                           
                           for letter in findword {
                               if (aimword.uppercased().contains(letter.uppercased())) {
                                   loadedstring += "\(letter.uppercased())"
                               } else {
                                   loadedstring += "_ "
                               }
                           }
                           userGuessLabel.text = loadedstring
                           
                           if (!findword.contains(aimword.uppercased())) {
                               correctCount += 1
                           }
                           
                           if userGuessLabel.text!.contains("_") == false {
                               if (remsining > 0 && gameLEVL < 5) {
                                   guessBtn.isEnabled = false
                                   displayImage.isHidden = false
                                   displayImage.image = UIImage(named: cityguesswords[gameLEVL][2])
                                   
                                   guessCountLabel.text = "Wow! You have made \(noofattempts) guesses to guess the word!"
                                   playAgainBtn.isHidden = false
                                   playAgainBtn.isEnabled = true
                                   wordsfound += 1
                                   remsining -= 1
                                   gameLEVL += 1
                                   guessletterField.text = ""
                                   wordsGuessedLabel.text = "Total number of words guessed successfully: \(wordsfound)"
                                   wordsRemainingLabel.text = "Total number of words remaining in game: \(remsining)"
                                   totalWordsLabel.text = "Total number of words in game: \(cityguesswords.count)"
                                   aimword = ""
                                   noofattempts = 0
                                   correctCount = 0
                               }
                           } else {
                               guessCountLabel.text = "You have made \(noofattempts) guesses"
                           }
                       } else {
                           guessCountLabel.text = "You have used all the available guesses, Please play again"
                           hintLabel.text = ""
                           guessletterField.text = ""
                           guessBtn.isEnabled = false
                           playAgainBtn.isHidden = false
                           playAgainBtn.isEnabled = true
                           noofattempts = 0
                       }
    }
    
    @IBAction func CharEntered(_ sender: UITextField) {
        
        let enteredText = guessletterField.text!
                   if (enteredText.isEmpty) {
                       guessBtn.isEnabled = false
                   } else {
                       guessBtn.isEnabled = true
                   }
    }
    
    func gameFinished() {
                statusLabel.isHidden = false
                statusLabel.text = "Congratulations! You are done with the game! Please start over again"
                displayImage.isHidden = false
                displayImage.image = UIImage(named: "All")
            
                
            }
    
    @IBAction func playAgainButtonPressed(_ sender: UIButton) {
        
        if (wordsfound == 5) {
                            statusLabel.isHidden = false
                            statusLabel.text = "Congratulations! You are done with the game! Please start over again"
                            displayImage.isHidden = false
                            displayImage.image = UIImage(named: "All")
                            gameLEVL = 0
                            remsining = 5
                            wordsfound = 0
                            noofattempts = 0
                            aimword = ""
                            hintLabel.text = ""
                            guessCountLabel.text = ""
                            userGuessLabel.text = ""
                            wordsGuessedLabel.text = "Total number of words guessed successfully: \(wordsfound)"
                            wordsRemainingLabel.text = "Total number of words remaining in game: \(remsining)"
                            totalWordsLabel.text = "Total number of words in game: \(cityguesswords.count)"
                        } else {
                            updateUser(l: gameLEVL)
                            
                        }
      
        }

func updateUser(l: Int) {
    wordsGuessedLabel.text = "Total number of words guessed successfully: \(wordsfound)"
                wordsRemainingLabel.text = "Total number of words remaining in game: \(remsining)"
                totalWordsLabel.text = "Total number of words in game: \(cityguesswords.count)"
                guessCountLabel.text = "You have made 0 guesses"
                displayImage.isHidden = true
                guessletterField.text = ""
                playAgainBtn.isHidden = true
                playAgainBtn.isEnabled = true
                statusLabel.isHidden = true
                statusLabel.isEnabled = false
                
                var tempStr = ""
                let wordStr = cityguesswords[l][0]
                for _ in wordStr {
                    tempStr += "_" + " "
                }
                userGuessLabel.text = "\(tempStr)"
                hintLabel.text = "Hint: \(cityguesswords[l][1])"
                loadedstring = ""
            
        
   }
//func gameFinished() {
//       statusLabel.isHidden = false
//       statusLabel.text = "Congratulations! You are done with the game! Please start over again"
//       displayImage.isHidden = false
//       displayImage.image = UIImage(named: "All")
//   }
    @IBOutlet weak var displayImage: UIImageView!
    }

