//
//  ViewController.swift
//  TableViewDemo
//
//  Created by Bala Venkata Sai Kishore Vattumilli on 3/28/24.
//

import UIKit

class Product{
    var productName:String?
    var productcategory:String?
    
    init(productName: String? = nil, productcategory: String? = nil) {
        self.productName = productName
        self.productcategory = productcategory
    }
    
}



class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        //return the number of products
        return products.count
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        //create a cell
        var cell = tableViewOL.dequeueReusableCell(withIdentifier: "ReusableCell", for: indexPath)
        //populate a cell
        cell.textLabel?.text = products[indexPath.row].productName
        
        //return a cell
        
        return cell
    }
    
    
    @IBOutlet weak var tableViewOL: UITableView!
    
    var products=[Product]()
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        tableViewOL.delegate = self
        tableViewOL.dataSource = self
        
        let p1 = Product(productName: "iphone",productcategory: "Mobile Phone")
        products.append(p1)
        
        let p2 = Product(productName: "MacBook",productcategory: "laptop")
        products.append(p2)
        
        let p3 = Product(productName: "VisionPro",productcategory: "ArgumentedReality")
        products.append(p3)
        let p4 = Product(productName: "iPencil",productcategory: "Accessories")
        products.append(p4)
        
        let p5 = Product(productName: "EarBuds",productcategory: "Bluetooth")
        products.append(p5)
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        let transition = segue.identifier
        if(segue.identifier == "prodDescriptionSegue")
        {
            let destination = segue.destination as! DescriptionViewController
            destination.product = products[(tableViewOL.indexPathForSelectedRow?.row)!]
            
        }
        
    }


}

