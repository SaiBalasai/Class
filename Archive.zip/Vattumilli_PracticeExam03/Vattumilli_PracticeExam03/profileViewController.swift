//
//  HomeViewController.swift
//  Vattumilli_PracticeExam03
//
//  Created by Bala Venkata Sai Kishore Vattumilli on 4/16/24.
//

import UIKit

class profileViewController: UIViewController {
    
    var value:Name?
  
    
    @IBOutlet weak var initialsOL: UILabel!
    
    
    @IBOutlet weak var phoneNumberOL: UILabel!
    
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Contact Details"
        
        initialsOL.text = "Initials: \((value?.initial)!)"
        
        phoneNumberOL.text = "Phone Number: \((value?.number)!)"
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
