//
//  ViewController.swift
//  Vattumilli_PracticeExam03
//
//  Created by Bala Venkata Sai Kishore Vattumilli on 4/16/24.
//

import UIKit

class Name{
    var fullName:String?
    var number:String?
    var initial:String?
    
    init(fullName: String? = nil, number: String? = nil, initial: String? = nil) {
        self.fullName = fullName
        self.number = number
        self.initial = initial
    }
    
}

class HomeViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return name.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        //create a cell
        let cell = TableViewOL.dequeueReusableCell(withIdentifier: "contactCell", for: indexPath)
        //populate a cell
        cell.textLabel?.text = name[indexPath.row].fullName
        
        return cell
    }
    
    
    
    
    @IBOutlet weak var TableViewOL: UITableView!
    
    
    var name=[Name]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Contact"
        
        // Do any additional setup after loading the view.
        self.TableViewOL.delegate = self
        self.TableViewOL.dataSource = self
        
        let p1 = Name(fullName:"John Abraham",number:"999-999-9999",initial:"A.J")
        name.append(p1)
        let p2 = Name(fullName:"Ram Krishna",number:"660-528-7765",initial:"K.R")
        name.append(p2)
        let p3 = Name(fullName:"Hari Krishna",number:"660-528-2265",initial:"H.K")
        name.append(p3)
        let p4 = Name(fullName:"Bharath Vemu",number:"660-528-8822",initial:"V.B")
        name.append(p4)
        let p5 = Name(fullName:"Chandan Vavilala",number:"660-528-2214",initial:"V.C")
        name.append(p5)
        let p6 = Name(fullName:"Harish Vavilala",number:"660-528-3312",initial:"V.H")
        name.append(p6)
        let p7 = Name(fullName:"Kumar Mal/lireddy",number:"302-444-1208",initial:"M.K")
        name.append(p7)
        let p8 = Name(fullName:"Nitish Madavalli",number:"660-528-8811",initial:"M.N")
        name.append(p8)
        let p9 = Name(fullName:"Namruth Potla",number:"660-528-8812",initial:"P.N")
        name.append(p9)
        let p10 = Name(fullName:"Akshay Attuluru",number:"660-528-3333",initial:"A.A")
        name.append(p10)
        
        
        
        
        
        
        
        
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        let transition = segue.identifier
        
        if(transition == "contactSegue")
        {
           
            let destination = segue.destination as! profileViewController
            
            destination.value = name[(TableViewOL.indexPathForSelectedRow?.row)!]
           
            
        }
        
        
    }
    
    
}
