//
//  ViewController.swift
//  VowelTester
//
//  Created by Vattumilli,Bala Venkata Sai Kishore on 1/25/24.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var inputOL: UITextField!
    @IBOutlet weak var outputOL: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func CheckBtnClicked(_ sender: Any) {
        
        //Read the Entered Text and assaign it to a variable.
        
        var  input = inputOL.text!
        
        
        //Check for vowels using if statement
        if(input.contains("a") || input.contains("e") || input.contains("i") || input.contains("o") || input.contains("u")){
            //print the message
            print()
            //assign the output to output label
            outputOL.text = "\(input) contains vowels 😁"
        }
        else{
            //assign the output to output label
            
            outputOL.text = "\(input)does not contains vowels 🫣"
        }
        
    }
    
}

